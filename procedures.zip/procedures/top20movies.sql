select movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s
where movies.id = ratings.movieId 
group by title
order by rating desc limit 20 