USE moviedb;
DROP procedure IF EXISTS add_star;

DELIMITER $$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_star`(
						 	#IN _title varchar(200),
                            IN star_name varchar(200), 
                            IN birth_year int(11),
                            
							OUT output varchar(200) )
BEGIN
    
    DECLARE movie_id varchar(200) default -1;
    DECLARE star_id varchar(200) default -1;
    DECLARE maxstar varchar(10);
    DECLARE message  varchar(200) DEFAULT "";
    
    
    START TRANSACTION;
    
		set maxstar = (select endId from maxid where tablename = 'stars');
		#set maxstar = cast((SUBSTRING(maxstar,3,9)) as unsigned);
        set maxstar = maxstar + 1;
        SET star_id = concat("nm",cast(maxstar as char));
        insert into stars(id, name, birthYear) values (star_id, star_name, birth_year);
        UPDATE `moviedb`.`maxid` SET `endId`= maxstar WHERE `tablename`='stars';
        SET output = "Add new star!";


    COMMIT;
    
END

$$

DELIMITER ;