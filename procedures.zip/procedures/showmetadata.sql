use moviedb;
SELECT COLUMN_NAME, IS_NULLABLE, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'moviedb' AND TABLE_NAME =  'stars';
#select * from genres
#delete from movies where id like 'zz%';
#ALTER TABLE movies MODIFY director varchar(100);