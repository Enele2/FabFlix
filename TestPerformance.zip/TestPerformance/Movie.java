import java.util.HashSet;
import java.util.Set;

public class Movie {
	
	String id = null;
	String title = null;
	int year = 0;
	String director = null;
	Set<String> genres = new HashSet<>();
}
