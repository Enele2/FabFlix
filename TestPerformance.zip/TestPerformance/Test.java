import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Test {

    Document dom;
    Map<String, List<Movie>> directorfilms = new HashMap<>();
    Set<String> genres = new HashSet<>();

    public void runExample() {

        //parse the xml file and get the dom object
        parseXmlFile();

        //get each employee element and create a Employee object
        parseDocument();
        
        //System.out.println(genres.size());
        //for (String genre : genres) System.out.println(genre);
        
        try {
        	insertGenres();
         	insertDb();
    	} catch (Exception e) {}

    }

    private void parseXmlFile() {
        //get the factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {

            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            //parse using builder to get DOM representation of the XML file
            dom = db.parse("mains243.xml");

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (SAXException se) {
            se.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private void parseDocument() {
        //get the root elememt
        Element docEle = dom.getDocumentElement();

        //get a nodelist of <employee> elements
        NodeList nl = docEle.getElementsByTagName("directorfilms");
        if (nl != null && nl.getLength() > 0) {
            for (int i = 0; i < nl.getLength(); i++) {
            	parseDirectorfilms((Element) nl.item(i));
            }
        }
    }
    
    private void parseDirectorfilms(Element element) {
    	NodeList directorNl = element.getElementsByTagName("director");
        String director = getVal((Element) directorNl.item(0), "dirname");
        
        if (director == null) return;
        if (!directorfilms.containsKey(director)) {
        	directorfilms.put(director, new ArrayList<>());
        }
        List<Movie> films = directorfilms.get(director);
        
        NodeList filmsNl = element.getElementsByTagName("films");
        for (int i = 0; i < filmsNl.getLength(); i++) {
        	parseFilms((Element) filmsNl.item(i), films);
        }
    }
    
    private void parseFilms(Element element, List<Movie> films) {
    	NodeList nl = element.getElementsByTagName("film");
        for (int i = 0; i < nl.getLength(); i++) {
        	Element el = (Element) nl.item(i);
        	Movie movie = new Movie();
        	movie.id = getVal(el, "fid");
        	movie.title = getVal(el, "t");
        	try {
        		movie.year = Integer.parseInt(getVal(el, "year"));
        	} catch (Exception e) {
        	}
        	NodeList cats = el.getElementsByTagName("cats");
        	if (cats != null) {
        		for (int j = 0; j < cats.getLength(); j++) {
        			NodeList cat = ((Element) cats.item(j)).getElementsByTagName("cat");
        			if (cat != null) {
        				for (int k = 0; k < cat.getLength(); k++) {
        					Element child = (Element) cat.item(k);
        					if (child.hasChildNodes()) {
        						String catVal = child.getFirstChild().getNodeValue();
        						if (catVal != null) {
        							catVal = catVal.trim().toLowerCase();
        							if (catVal.length() != 0) {
        							    movie.genres.add(catVal);
        							    genres.add(catVal);
        							}
        						}
        					}
        				}
        			}
        		}
        	}
        	films.add(movie);
        }
    }
    
    private String getVal(Element element, String tag) {
    	NodeList nl = element.getElementsByTagName(tag);
    	Element el = (Element) nl.item(0);
    	if (el == null) return null;
    	if (!el.hasChildNodes()) return null;
    	return el.getFirstChild().getNodeValue();
    }
    
    private void insertDb() throws Exception {
    	String loginUser = "root";
        String loginPasswd = "lucifer";
        String loginUrl = "jdbc:mysql://localhost:3306/moviedb";

        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection connection = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);
        
        PreparedStatement psInsertRecord = null;
        String sqlInsertRecord = null;

        int[] iNoRows = null;
        
        sqlInsertRecord = "insert into movies (id, title, year, director) values(?, ?, ?, ?)";
        try {
			connection.setAutoCommit(false);

            psInsertRecord = connection.prepareStatement(sqlInsertRecord);
            
            int cnt = 0;
            
            for (String director : directorfilms.keySet()) {
            	for (Movie movie : directorfilms.get(director)) {
            		cnt++;
            		psInsertRecord.setString(1, "zz" + cnt);
            		if (movie.title == null) {
            			psInsertRecord.setNull(2, java.sql.Types.VARCHAR);
            		} else {
            			psInsertRecord.setString(2, movie.title);
            		}
            		if (movie.year == 0) {
            			psInsertRecord.setNull(3, java.sql.Types.INTEGER);
            		} else {
            			psInsertRecord.setInt(3, movie.year);
            		}
            		if (director == null) {
            			psInsertRecord.setNull(4, java.sql.Types.VARCHAR);
            		} else {
            			psInsertRecord.setString(4, director);
            		}
                    psInsertRecord.addBatch();
            	}
            	//iNoRows = psInsertRecord.executeBatch();
            }
            
            iNoRows = psInsertRecord.executeBatch();

			connection.commit();

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if (psInsertRecord != null) psInsertRecord.close();
            if (connection != null) connection.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    private void insertGenres() throws Exception {
    	String loginUser = "root";
        String loginPasswd = "lucifer";
        String loginUrl = "jdbc:mysql://localhost:3306/moviedb";

        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection connection = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);
        
        PreparedStatement psInsertRecord = null;
        String sqlInsertRecord = null;

        int[] iNoRows = null;
        
        sqlInsertRecord = "insert into genres (name) values(?)";
        try {
			connection.setAutoCommit(false);

            psInsertRecord = connection.prepareStatement(sqlInsertRecord);
            
            for (String genre : genres) {
            	psInsertRecord.setString(1, genre);
            	psInsertRecord.addBatch();
            }
            
            iNoRows = psInsertRecord.executeBatch();

			connection.commit();

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if (psInsertRecord != null) psInsertRecord.close();
            if (connection != null) connection.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        //create an instance
        Test test = new Test();

        //call run example
        test.runExample();
    }

}
