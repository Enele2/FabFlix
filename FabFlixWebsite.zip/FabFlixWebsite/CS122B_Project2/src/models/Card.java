package cs122B.FabFlix.Model;

public class Card {
	private final String id;
	
	public Card(String id) {
		this.id = id;
	}
	
	public String getId() {
		return this.id;
	}

}
