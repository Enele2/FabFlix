import com.google.gson.JsonObject;


import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.jasypt.util.password.PasswordEncryptor;
import org.jasypt.util.password.StrongPasswordEncryptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "LoginServlet", urlPatterns = "/api/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
 	@Resource(name = "jdbc/moviedb")
 	private DataSource dataSource;
 	
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    		throws IOException {
    	// Output stream to STDOUT
     	PrintWriter out = response.getWriter();
    	
    	String gRecaptchaResponse = request.getParameter("g-recaptcha-response");
        System.out.println("gRecaptchaResponse=" + gRecaptchaResponse);
        

        // Verify reCAPTCHA
        try {
            RecaptchaVerifyUtils.verify(gRecaptchaResponse);
        } catch (Exception e) {
            out.println("<html>");
            out.println("<head><title>Error</title></head>");
            out.println("<body>");
            out.println("<p>recaptcha verification error</p>");
            out.println("<p>" + e.getMessage() + "</p>");
            out.println("</body>");
            out.println("</html>");
            
            out.close();
            return;
        }
    	
    	
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
       
        try {
        	// Get a connection from dataSource
     		Connection dbcon = dataSource.getConnection();
     		// Construct a query with parameter represented by "?"
     		String query = "select * from customers where customers.email=?";

     		// Declare our statement
     		PreparedStatement statement = dbcon.prepareStatement(query);
     		// Set the parameter represented by "?" in the query to the email we get from the form,
     		// num 1 indicates the first "?" in the query
     		statement.setString(1, email);
        
     		// Perform the query
     		ResultSet rs = statement.executeQuery();
     		
     		boolean success = false;
     		if (rs.next()) {
     			//String encryptedPassword = rs.getString("password");
     			//System.out.println(encryptedPassword);
     			// use the same encryptor to compare the user input password with encrypted password stored in DB
    			//success = new StrongPasswordEncryptor().checkPassword(password, encryptedPassword);
                JsonObject responseJsonObject = new JsonObject();
     			if(rs.getString("password") != null) {
     				success = true;
     			}
    			if(success) {
                // Set this user into current session
	                String sessionId = ((HttpServletRequest) request).getSession().getId();
	                Long lastAccessTime = ((HttpServletRequest) request).getSession().getLastAccessedTime();
	                request.getSession().setAttribute("user", new User(email));
	
	                responseJsonObject.addProperty("status", "success");
	                responseJsonObject.addProperty("message", "success");
	
	                response.getWriter().write(responseJsonObject.toString());
    			} else {
    	             responseJsonObject.addProperty("status", "fail");
    	             responseJsonObject.addProperty("message", "incorrect username or password");
    	             out.write(responseJsonObject.toString());
    			}
     		}else {
                JsonObject responseJsonObject = new JsonObject();
     			responseJsonObject.addProperty("status", "fail");
	            responseJsonObject.addProperty("message", "incorrect username or password");
	            out.write(responseJsonObject.toString());
     		}
     		
     		rs.close();
    		dbcon.close();
    		dbcon.close();

        } catch (Exception e) {
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set response status to 500 (Internal Server Error)
			response.setStatus(500);
		}
    }
}
