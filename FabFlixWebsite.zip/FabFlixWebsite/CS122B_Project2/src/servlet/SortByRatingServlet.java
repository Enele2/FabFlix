import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "SortByRatingServlet", urlPatterns = "/api/sortbyrating")
public class SortByRatingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Create a dataSource which registered in web.xml
 	@Resource(name = "jdbc/moviedb")
 	private DataSource dataSource;
 	
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGET(HttpServletRequest request, HttpServletResponse response) 
    		throws IOException {
    	HttpSession session = request.getSession();
        String sessionId = session.getId();
        
        Long lastAccessTime = session.getLastAccessedTime();
        System.out.println(session.getAttribute("keywords"));
//        JsonObject responseJsonObject = new JsonObject();
//        responseJsonObject.addProperty("sessionID", sessionId);
//        responseJsonObject.addProperty("lastAccessTime", new Date(lastAccessTime).toString());
//        responseJsonObject.addProperty("data", session.getAttribute("data").toString());
        
        //responseJsonObject.addProperty("data", session.getAttribute("data").toString());
        // write all the data into the jsonObject
        //response.getWriter().write(responseJsonObject.toString());
//        String title = session.getAttribute("keywords");
//        String year = request.getParameter("year");
//        String director = request.getParameter("director");
//        String starName = request.getParameter("starName");
	      String title = "";
	      String year = "2003";
	      String director = "";
	      String starName = "";
        // Output stream to STDOUT
     	PrintWriter out = response.getWriter();
        try {
        	// Get a connection from dataSource
     		Connection dbcon = dataSource.getConnection();
     		String query = "";
     		PreparedStatement statement;
     		// Construct a query with parameter represented by "?"
     		if(title.equals("") && year.equals("") && director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, starName);
     		}else if(title.equals("") && year.equals("") && !director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.director like ?) as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + director + "%");
     		}else if(title.equals("") && !year.equals("") && director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.year = ?) as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, year);
     		}else if(!title.equals("") && year.equals("") && director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.year = ?) as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     		}else if(!title.equals("") && !year.equals("") && director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.year = ?) as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, year);
     		}else if(!title.equals("") && year.equals("") && !director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.director like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, director);
     		}else if(!title.equals("") && year.equals("") && director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, starName);
     		}else if(title.equals("") && !year.equals("") && !director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.year = ? and movies.director like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, year);
     			statement.setString(2, director);
     		}else if(title.equals("") && !year.equals("") && director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.year = ? and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, year);
     			statement.setString(2, starName);
     		}else if(title.equals("") && year.equals("") && !director.equals("") && !starName.equals("")) {
     			query = "select * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.director like '%?%' and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, director);
     			statement.setString(2, starName);
     		}else if(!title.equals("") && !year.equals("") && !director.equals("") && starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.year = ? and movies.director like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, year);
     			statement.setString(3, director);
     		}else if(!title.equals("") && !year.equals("") && director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.year = ? and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, year);
     			statement.setString(3, starName);
     		}else if(!title.equals("") && year.equals("") && !director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.director like '%?%' and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, director);
     			statement.setString(3, starName);
     		}else if(title.equals("") && !year.equals("") && !director.equals("") && !starName.equals("")) {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and  movies.year = ? and movies.director like '%?%' and stars.name like '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, year);
     			statement.setString(2, director);
     			statement.setString(3, starName);
     		}else {
     			query = "select distinct * from (select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId) as m natural join (select title from movies, stars, stars_in_movies where movies.id = movieId and stars.id = starId and movies.title like '%?%' and movies.year = ? and movies.director like '%?%' and stars.name = '%?%') as n order by rating desc";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, title);
     			statement.setString(2, year);
     			statement.setString(3, director);
     			statement.setString(4, starName);
     		}
     		System.out.println("Fuck: " + statement.toString());
     		

     		// Declare our statement
     		

     		// Set the parameter represented by "?" in the query to the id we get from url,
     		// num 1 indicates the first "?" in the query
     		
     		//statement.setString(2, password);
        
     		// Perform the query
     		ResultSet rs = statement.executeQuery();
     		
     		JsonArray jsonArray = new JsonArray();

            // Iterate through each row of rs
            while (rs.next()) {
            	String movie_id = rs.getString("id");
                String movie_title = rs.getString("title");
                String movie_year = rs.getString("year");
                String movie_director = rs.getString("director");
                String movie_genres = rs.getString("genres");
                String movie_stars = rs.getString("stars");
                String movie_rating = rs.getString("rating");

                // Create a JsonObject based on the data we retrieve from rs
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("status", "success");
                jsonObject.addProperty("movie_id", movie_id);
                jsonObject.addProperty("movie_title", movie_title);
                jsonObject.addProperty("movie_year", movie_year);
                jsonObject.addProperty("movie_director", movie_director);
                jsonObject.addProperty("movie_genres", movie_genres);
                jsonObject.addProperty("movie_stars", movie_stars);
                jsonObject.addProperty("movie_rating", movie_rating);

                jsonArray.add(jsonObject);
            }
            

            
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

            rs.close();
            statement.close();
            dbcon.close();
            
        } catch (Exception e) {
			// write error message JSON object to output
        	System.out.print(e);
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set response status to 500 (Internal Server Error)
			response.setStatus(500);
		}
   
    }
}
