import com.google.gson.JsonObject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

/**
 * This IndexServlet is declared in the web annotation below, 
 * which is mapped to the URL pattern /api/index.
 */
@WebServlet(name = "SearchResultServlet", urlPatterns = "/api/searchingresult")
public class SearchResultServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * handles GET requests to add and show the item list information
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        
        HttpSession session = request.getSession();
        String sessionId = session.getId();
        
        Long lastAccessTime = session.getLastAccessedTime();

        JsonObject responseJsonObject = new JsonObject();
        responseJsonObject.addProperty("sessionID", sessionId);
        responseJsonObject.addProperty("lastAccessTime", new Date(lastAccessTime).toString());
        responseJsonObject.addProperty("data", session.getAttribute("data").toString());
        
        //responseJsonObject.addProperty("data", session.getAttribute("data").toString());
        // write all the data into the jsonObject
        response.getWriter().write(responseJsonObject.toString());
        System.out.println(session.getAttribute("data").toString());
        
    }
}
