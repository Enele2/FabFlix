//import java.io.IOException;
//import java.io.PrintWriter;
//import com.mysql.jdbc.Connection;
//import java.sql.DatabaseMetaData;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//
//import javax.annotation.Resource;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.sql.DataSource;
//
//import com.google.gson.JsonArray;
//import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.sql.Connection;
import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mysql.jdbc.CallableStatement;
//import com.mysql.jdbc.Connection;

// Declaring a WebServlet called StarsServlet, which maps to url "/api/stars"
@WebServlet(name = "ShowMetaDataServlet", urlPatterns = "/api/showmetadata")
public class ShowMetaDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
    @Resource(name = "jdbc/moviedb")
    private DataSource dataSource;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json"); // Response mime type
		System.out.println("call metadata");

        // Output stream to STDOUT
        PrintWriter out = response.getWriter();

        try {
            // Get a connection from dataSource
        	Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/moviedb");
            if (ds == null)
                out.println("ds is null.");

            Connection conn = ds.getConnection();
            if (conn == null)
                out.println("conn is null.");
        	//Connection conn = dataSource.getConnection();

            DatabaseMetaData databaseMetaData = conn.getMetaData();
			Statement stmt = conn.createStatement();
			ResultSet rs = databaseMetaData.getTables(conn.getCatalog(), "root", null, new String[]{"TABLE"});
			JsonArray jsonArray = new JsonArray();
			ArrayList<String> table = new ArrayList<>();
			String sql = "";
			out = response.getWriter();	
			System.out.println("connection");
			while (rs.next()) {
				table.add(rs.getString("TABLE_NAME"));
			}
			
			
			for(String curr:table) {
				//System.out.println(curr);
				//COLUMN_NAME, IS_NULLABLE(YES/NO), DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
				sql = "SELECT COLUMN_NAME, IS_NULLABLE, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'moviedb' AND TABLE_NAME = '"+ curr +"'";
				System.out.println(sql);
				rs = stmt.executeQuery(sql);
				while(rs.next()) {
					String COLUMN_NAME = rs.getString("COLUMN_NAME");
					String IS_NULLABLE = rs.getString("IS_NULLABLE");
					String DATA_TYPE = rs.getString("DATA_TYPE");
					//
					JsonObject jsonObject = new JsonObject();
					jsonObject.addProperty("TABLE_NAME", curr);
					jsonObject.addProperty("COLUMN_NAME", COLUMN_NAME);
					System.out.println(COLUMN_NAME);
					jsonObject.addProperty("IS_NULLABLE", IS_NULLABLE);
					jsonObject.addProperty("DATA_TYPE", DATA_TYPE);
					jsonArray.add(jsonObject);
				}
			}
			out.write(jsonArray.toString());
		}catch (SQLException ex) {
		    while (ex != null) {
		        System.out.println("SQL Exception:  " + ex.getMessage());
		        ex = ex.getNextException();
		        }
		}catch (Exception ex){
			return;
		}
    }
}
