public class RecaptchaConstants {
	
    public static final String SECRET_KEY ="6LfoZZAUAAAAAHV1-cr2bUWGqfa7bnRwxkK233jT";

}
