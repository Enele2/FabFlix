import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import com.mysql.jdbc.CallableStatement;


import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "AddStarServlet", urlPatterns = "/api/addstar")
public class AddStarServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
 	@Resource(name = "jdbc/moviedb")
 	private DataSource dataSource;
 	
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    		throws IOException {
	    	String dbURL = "jdbc:mysql://localhost:3306/moviedb";
	        String user = "mytestuser";
	        String password = "mypassword";
	        String starName = request.getParameter("starName");
	        String birthYear = request.getParameter("birthYear");
	        int birthyear = 0;
	        if (!request.getParameter("birthYear").equals("")) {
	        	birthyear = Integer.parseInt(request.getParameter("birthYear"));
	        }
		    
		   
        
        
        // Output stream to STDOUT
     	PrintWriter out = response.getWriter();
        try {
        	// Get a connection from dataSource
     		//Connection dbcon = dataSource.getConnection();
        	Connection dbcon = DriverManager.getConnection(dbURL, user, password);
     		String sql = "";
     		//PreparedStatement statement;
     		// Construct a query with parameter represented by "?"
     		sql = "{call add_star(?,?,?)}";
			System.out.println(sql);
			//try{
				//Class.forName("com.mysql.jdbc.Driver").newInstance();
				//Connection conn = (Connection) java.sql.DriverManager.getConnection(URL, user, password);
				
				
				//Context initCtx = new InitialContext();
	            //Context envCtx = (Context) initCtx.lookup("java:comp/env");
	            //DataSource ds = (DataSource) envCtx.lookup("jdbc/Master");
	            
				CallableStatement state = (CallableStatement) dbcon.prepareCall(sql);
				//CallableStatement state = (CallableStatement) dbcon.prepareCall(sql);
				state.setString(1, starName);
				if (!request.getParameter("birthYear").equals("")) {
					state.setInt(2, birthyear);
				} else {
					state.setNull(2, java.sql.Types.INTEGER);
				}
				
				state.registerOutParameter(3,Types.VARCHAR);
				
				out = response.getWriter();	
			    state.executeUpdate();
			    String output = state.getString(3);
			    System.out.println(output);
			    
				//JsonArray jsonArray = new JsonArray();
			    JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("output", output);
				//jsonArray.add(jsonObject);
				out.write(jsonObject.toString());
			    
				dbcon.close();
				
			}catch(Exception e) {
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
				System.out.println(e);

				// set response status to 500 (Internal Server Error)
				response.setStatus(500);
			}
     		
     		

     		// Declare our statement
     		

     		// Set the parameter represented by "?" in the query to the id we get from url,
     		// num 1 indicates the first "?" in the query
     		
     		//statement.setString(2, password);
        
     		// Perform the query

   
    }
}
