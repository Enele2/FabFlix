import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import com.mysql.jdbc.CallableStatement;


import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "AddMovieServlet", urlPatterns = "/api/addmovie")
public class AddMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
 	@Resource(name = "jdbc/moviedb")
 	private DataSource dataSource;
 	
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    		throws IOException {
	    	String dbURL = "jdbc:mysql://localhost:3306/moviedb";
	        String user = "mytestuser";
	        String password = "mypassword";
	        
	        String title = request.getParameter("title");
	        String director = request.getParameter("director");
		    int year = Integer.parseInt(request.getParameter("year"));
		    String starName = request.getParameter("starName");
		    String genre = request.getParameter("genre");
        
        // Output stream to STDOUT
     	PrintWriter out = response.getWriter();
        try {
        	// Get a connection from dataSource
     		//Connection dbcon = dataSource.getConnection();
        	Connection dbcon = DriverManager.getConnection(dbURL, user, password);
     		String sql = "";
     		//PreparedStatement statement;
     		// Construct a query with parameter represented by "?"
     		sql = "{call add_movie(?,?,?,?,?,?)}";
			System.out.println(sql);
			//try{
				//Class.forName("com.mysql.jdbc.Driver").newInstance();
				//Connection conn = (Connection) java.sql.DriverManager.getConnection(URL, user, password);
				
				
				//Context initCtx = new InitialContext();
	            //Context envCtx = (Context) initCtx.lookup("java:comp/env");
	            //DataSource ds = (DataSource) envCtx.lookup("jdbc/Master");
	            
				CallableStatement state = (CallableStatement) dbcon.prepareCall(sql);
				//CallableStatement state = (CallableStatement) dbcon.prepareCall(sql);
				state.setString(1, title);
				state.setInt(2, year);
				state.setString(3, director);
				state.setString(4, starName);
				state.setString(5, genre);
				state.registerOutParameter(6,Types.VARCHAR);
				
				out = response.getWriter();	
			    state.executeUpdate();
			    String output = state.getString(6);
			    System.out.println(output);
			    
				//JsonArray jsonArray = new JsonArray();
			    JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("output", output);
				//jsonArray.add(jsonObject);
				out.write(jsonObject.toString());
			    
				dbcon.close();
				
			}catch(Exception e) {
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
				System.out.println(e);

				// set response status to 500 (Internal Server Error)
				response.setStatus(500);
			}
     		
     		

     		// Declare our statement
     		

     		// Set the parameter represented by "?" in the query to the id we get from url,
     		// num 1 indicates the first "?" in the query
     		
     		//statement.setString(2, password);
        
     		// Perform the query

   
    }
}
