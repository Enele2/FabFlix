import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "SearchingServlet", urlPatterns = "/api/searching")
public class SearchingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
 	@Resource(name = "jdbc/moviedb")
 	private DataSource dataSource;
 	
    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
    		throws IOException {
    	
    	String dbURL = "jdbc:mysql://localhost:3306/moviedb";
        String user = "mytestuser";
        String password = "mypassword";
    	
    	
	    String title = request.getParameter("title");
	    String getYear = request.getParameter("year");
	    int year = 0;
	    if (!getYear.equals("")) {
	    	year = Integer.parseInt(request.getParameter("year"));
	    }
	    String director = request.getParameter("director");
	    String starName = request.getParameter("starName");
	    System.out.println(title);
	    System.out.println(year);
	    System.out.println(director);
	    System.out.println(starName);
        //String []str = {title, year, director, starName};
        
        // Output stream to STDOUT
     	PrintWriter out = response.getWriter();
        try {
        	// Get a connection from dataSource
        	//Connection dbcon = DriverManager.getConnection(dbURL, user, password);
        	
        	Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/moviedb");

            // the following commented lines are direct connections without pooling
            //Class.forName("org.gjt.mm.mysql.Driver");
            //Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

            if (ds == null)
                out.println("ds is null.");

            Connection dbcon = ds.getConnection();
            if (dbcon == null)
                out.println("dbcon is null.");

        	//Connection dbcon = dataSource.getConnection();
     		String query = "";
     		PreparedStatement statement;
     		// Construct a query with parameter represented by "?"
     		//case1: only starName
     		if(title.equals("") && year == 0 && director.equals("") && !starName.equals("")) {
     			
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + starName + "%");
     		//case2: only director
     		}else if(title.equals("") && year == 0 && !director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where director like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + director + "%");
     		//case3: only year
     		}else if(title.equals("") && year != 0 && director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, ifnull(s.stars, 'N/A') as stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where year = ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setInt(1, year);
     		//case4:only title
     		}else if(!title.equals("") && year == 0 && director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     		//case5: title & year
     		}else if(!title.equals("") && year != 0 && director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and year = ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setInt(2, year);
     		//case6: title & director
     		}else if(!title.equals("") && year == 0 && !director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and director like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setString(2, "%" + director + "%");
     		//case7: title & starName
     		}else if(!title.equals("") && year == 0 && director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setString(2, "%" + starName + "%");
     		//case8: year & director
     		}else if(title.equals("") && year != 0 && !director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where year = ? and director like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setInt(1, year);
     			statement.setString(2, "%" + director + "%");
     		//case9: year & starName
     		}else if(title.equals("") && year != 0 && director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where year = ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setInt(1, year);
     			statement.setString(2, "%" + starName + "%");
     		//case10: director & starName
     		}else if(title.equals("") && year == 0 && !director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where director like ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + director + "%");
     			statement.setString(2, "%" + starName + "%");
     		//case11: title & year & director
     		}else if(!title.equals("") && year != 0 && !director.equals("") && starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and year = ? and director like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setInt(2, year);
     			statement.setString(3, "%" + director + "%");
     		//case12: title & year & starName
     		}else if(!title.equals("") && year != 0 && director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and year = ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setInt(2, year);
     			statement.setString(3, "%" + starName + "?");
     		//case13: title & director & starName
     		}else if(!title.equals("") && year == 0 && !director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and director like ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setString(2, "%" + director + "%");
     			statement.setString(3, "%" + starName + "%");
     		//case14: year & director & starName
     		}else if(title.equals("") && year != 0 && !director.equals("") && !starName.equals("")) {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where year = ? and director like ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setInt(1, year);
     			statement.setString(2, "%" + director + "%");
     			statement.setString(3, "%" + starName + "%");
     		//case15: title & year & director & starName
     		}else {
     			query = "select coalesce(movies.id, ratings.movieId) id, ifnull(movies.title, 'N/A') as title" + 
     					", ifnull(movies.year, 0) as year, ifnull(movies.director, 'N/A') as director," + 
     					"ifnull(g.genres, 'N/A') as genres, s.stars" + 
     					", ifnull(ratings.rating, 0) as rating " + 
     					"from movies " + 
     					"     left outer join ratings on movies.id = ratings.movieId " + 
     					"	 left outer join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g on movies.id = g.movieId " + 
     					"     left outer join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s on movies.id = s.movieId " + 
     					"where title like ? and year = ? and director like ? and starName like ?;";
     			statement = dbcon.prepareStatement(query);
     			statement.setString(1, "%" + title + "%");
     			statement.setInt(2, year);
     			statement.setString(3, "%" + director + "%");
     			statement.setString(4, "%" + starName + "%");
     		}
     		
     		

     		// Declare our statement
     		

     		// Set the parameter represented by "?" in the query to the id we get from url,
     		// num 1 indicates the first "?" in the query
     		
     		
     		System.out.println(query);
     		// Perform the query
     		ResultSet rs = statement.executeQuery();
     		
     		JsonArray jsonArray = new JsonArray();

            // Iterate through each row of rs

     		while (rs.next()) {
     		
            	String movie_id = rs.getString("id");
                String movie_title = rs.getString("title");
                int movie_year = rs.getInt("year");
                String movie_director = rs.getString("director");
                String movie_genres = rs.getString("genres");
                String movie_stars = rs.getString("stars");
                String movie_rating = rs.getString("rating");

                // Create a JsonObject based on the data we retrieve from rs
                JsonObject jsonObject = new JsonObject();
                //jsonObject.addProperty("status", "success");
                jsonObject.addProperty("movie_id", movie_id);
                jsonObject.addProperty("movie_title", movie_title);
                jsonObject.addProperty("movie_year", movie_year);
                jsonObject.addProperty("movie_director", movie_director);
                jsonObject.addProperty("movie_genres", movie_genres);
                jsonObject.addProperty("movie_stars", movie_stars);
                jsonObject.addProperty("movie_rating", movie_rating);

                jsonArray.add(jsonObject);
            }
     		
            HttpSession session = request.getSession();

            session.setAttribute("data", jsonArray);
            //session.setAttribute("keywords", str);
            System.out.println(jsonArray);
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

            rs.close();
            statement.close();
            dbcon.close();
     		
        } catch (Exception e) {
			// write error message JSON object to output
        	System.out.print(e);
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set response status to 500 (Internal Server Error)
			response.setStatus(500);
		}
   
    }
}
