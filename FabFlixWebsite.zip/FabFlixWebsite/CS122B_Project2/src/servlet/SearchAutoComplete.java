
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class SearchAutoComplete
 */
@WebServlet(name = "SearchAutoComplete", urlPatterns = "/api/SearchAutoComplete")
public class SearchAutoComplete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(name = "jdbc/moviedb")
	private DataSource dataSource;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchAutoComplete() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.setContentType("application/json"); // Response mime type
		PrintWriter out = response.getWriter();
		JsonArray jsonArray = new JsonArray();

		HashMap<String, String> moviesTable = new HashMap<>();
		HashMap<String, String> starsTable = new HashMap<>();
		
		try {
			String query = request.getParameter("query");
			if (query == null || query.trim().isEmpty()) {
				response.getWriter().write(jsonArray.toString());
				return;
			}
			
			String[] split_query = query.split("\\s+");
			String sql_ = "";
			for (String curr : split_query) {
				if (curr.equals("of") || curr.equals("the") || curr.equals("an"))
					continue;
				sql_ += "+" + curr + "* ";
			}
			String sql = "SELECT * FROM movies WHERE MATCH (title) AGAINST ('" + sql_ + "' IN BOOLEAN MODE) limit 5;";
			
			Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/moviedb");
            if (ds == null)
                out.println("ds is null.");

            Connection conn = ds.getConnection();
            if (conn == null)
                out.println("conn is null.");
			
			Statement st = (Statement) conn.createStatement();
			ResultSet rs = st.executeQuery(sql);

			while (rs.next()) {
				String title = rs.getString("title");
				String id = rs.getString("id");
				//System.out.println(title + " " + id);
				moviesTable.put(id, title);
			}
			
			sql = "SELECT * FROM stars WHERE MATCH (name) AGAINST ('"+sql_+"' IN BOOLEAN MODE) limit 5;";
			rs = st.executeQuery(sql);

			while(rs.next()) {
				String name = rs.getString("name");
				String id = rs.getString("id");
				//System.out.println("Star: "+ name+ " "+ id);
				starsTable.put(id, name);
			}

			for (String id : moviesTable.keySet()) {
				String movieTitle = moviesTable.get(id);
				for(int i = 0; i<split_query.length; i++) {
					if (movieTitle.toLowerCase().contains(split_query[i].toLowerCase())) {
						jsonArray.add(generateJsonObject(id, movieTitle, "Movies"));
						break;
					}
				}
			}
			for (String id : starsTable.keySet()) {
				String heroName = starsTable.get(id);
				for(int i = 0; i<split_query.length; i++) {
					if (heroName.toLowerCase().contains(split_query[i].toLowerCase())) {
						jsonArray.add(generateJsonObject(id, heroName, "Stars"));
						break;
					}
				}
			}
			
			System.out.println(jsonArray.toString());
			response.getWriter().write(jsonArray.toString());
			conn.close();
			return;

		} catch (Exception e) {
			e.printStackTrace();
			response.sendError(500, e.getMessage());
		}

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private static JsonObject generateJsonObject(String heroID, String heroName, String categoryName) {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("value", heroName);

		JsonObject additionalDataJsonObject = new JsonObject();
		additionalDataJsonObject.addProperty("category", categoryName);
		additionalDataJsonObject.addProperty("heroID", heroID);

		jsonObject.add("data", additionalDataJsonObject);
		return jsonObject;

	}

}
