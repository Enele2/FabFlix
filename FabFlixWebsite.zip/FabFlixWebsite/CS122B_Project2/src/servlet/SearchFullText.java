

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class SearchFullText
 */
@WebServlet(name = "SearchFullText", urlPatterns = "/api/SearchFullText")

public class SearchFullText extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(name = "jdbc/moviedb")
	private DataSource dataSource;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchFullText() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json"); // Response mime type
		long startTime = System.nanoTime();
		PrintWriter out = response.getWriter();
		String movieTitle = request.getParameter("movieTitle");
		String search_year = "";
		String search_director = "";
		String search_star = "";
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/moviedb");

            // the following commented lines are direct connections without pooling
            //Class.forName("org.gjt.mm.mysql.Driver");
            //Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

            if (ds == null)
                out.println("ds is null.");

            Connection dbcon = ds.getConnection();
            if (dbcon == null)
                out.println("dbcon is null.");

			
			//Connection dbcon = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?serverTimezone=UTC","mytestuser","mypassword");


			//Connection dbcon = dataSource.getConnection();
			String query = "select movies.id, movies.title as title, movies.year as year, movies.director as director, g.genres, s.stars, ratings.rating from movies, ratings natural join (select movieId, group_concat(name separator',') as genres from genres, genres_in_movies where genres.id = genres_in_movies.genreId group by movieId) as g natural join (select movieId, group_concat(name separator',') as stars from stars, stars_in_movies where stars.id = stars_in_movies.starId group by movieId) as s where movies.id = ratings.movieId and movies.id = ?";
			query = "select Idmain as id, title, year, director, rating, group_concat(distinct genres.name separator '; ') as genres, group_concat(distinct stars.name separator'; ') as star "+

					"from (select movies.id as Idmain, movies.title, movies.year, movies.director, r.rating "

					+ "from movies , (select movieId, rating "
					+ " from ratings)as r "
					+ " where movies.id = r.movieId and (MATCH (title) AGAINST (? IN BOOLEAN MODE)) and (movies.year = ? or ? = '') and (movies.director like CONCAT('%', ?, '%') or ? = '')  "
					+ " order by title desc "
					+ " limit 0, 20) as tempmovies, genres_in_movies, genres, stars_in_movies, stars "
					+ "where genres_in_movies.movieId = Idmain and genres.id = genres_in_movies.genreId and stars_in_movies.movieId = Idmain and stars.id = stars_in_movies.starId and (stars.name like CONCAT('%', ?, '%') or ? = '') "
					+ "group by  Idmain, title, year, director, rating "
					+ " order by title desc";;
			PreparedStatement statement = dbcon.prepareStatement(query);
			if(movieTitle.contains(" ")) {
				String[] curr = movieTitle.split(" ");
				String newMovie = "";
				for(String temp:curr) {
					if(temp.equals("of")||temp.equals("the")||temp.equals("an"))
						continue;
					newMovie += "+"+temp+"* ";
				}
				statement.setString(1, newMovie);
			}else
				statement.setString(1, movieTitle);
				statement.setString(2, search_year);
				statement.setString(3, search_year);
				statement.setString(4, search_director);
				statement.setString(5, search_director);
				statement.setString(6, search_star);
				statement.setString(7, search_star);
				System.out.println(statement.toString());
			// Perform the query
			ResultSet rs = statement.executeQuery();

			JsonArray jsonArray = new JsonArray();

			// Iterate through each row of rs
			while (rs.next()) {
				String movieId = rs.getString("id");
				String movietitle = rs.getString("title");
				String movieYear = rs.getString("year");
				String movieDirector = rs.getString("director");
				String movieGenres = rs.getString("genres");
				String movieStars = rs.getString("star");
				System.out.println(movieId);
				//String movieRating = rs.getString("rating");
				// Create a JsonObject based on the data we retrieve from rs
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("id", movieId);
				jsonObject.addProperty("title", movietitle);
				jsonObject.addProperty("year", movieYear);
				jsonObject.addProperty("director", movieDirector);
				jsonObject.addProperty("genre", movieGenres);
				jsonObject.addProperty("star", movieStars);
				//jsonObject.addProperty("movie_rating", movieRating);
				jsonArray.add(jsonObject);
				System.out.println(jsonObject.toString());
			}
			
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

			rs.close();
			statement.close();
			//dbcon.close();
			
		}catch(Exception e) {
			e.printStackTrace();
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());
			response.setStatus(500);
		}
		out.close();
		 
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
