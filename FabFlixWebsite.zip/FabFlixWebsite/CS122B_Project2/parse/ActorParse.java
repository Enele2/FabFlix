import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

class Actor {
	String id = null;
	String name = null;
	int birthYear = 0;
}

public class ActorParse {

    Document dom;
    List<Actor> actors = new ArrayList<>();

    public void runExample() {

        //parse the xml file and get the dom object
        parseXmlFile();

        //get each employee element and create a Employee object
        parseDocument();
        
        try {
            insertDb();
    	} catch (Exception e) {}

    }

    private void parseXmlFile() {
        //get the factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {

            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();

            //parse using builder to get DOM representation of the XML file
            dom = db.parse("actors63.xml");

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (SAXException se) {
            se.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private void parseDocument() {
        //get the root elememt
        Element docEle = dom.getDocumentElement();

        //get a nodelist of <employee> elements
        NodeList nl = docEle.getElementsByTagName("actor");
        
        if (nl != null && nl.getLength() > 0) {
            for (int i = 0; i < nl.getLength(); i++) {
            	parseActor((Element) nl.item(i));
            }
        }
    }
    
    private void parseActor(Element element) {
    	Actor actor = new Actor();
    	actor.name = getVal(element, "stagename");
    	try {
    		actor.birthYear = Integer.parseInt(getVal(element, "dob"));
    	} catch (Exception e) {
    	}
    	
    	System.out.println("Actor name: " + actor.name + ", birth year: " + (actor.birthYear == 0 ? "inconsistent" : actor.birthYear));
    	
    	actors.add(actor);
    }
    
    private String getVal(Element element, String tag) {
    	NodeList nl = element.getElementsByTagName(tag);
    	Element el = (Element) nl.item(0);
    	if (el == null) return null;
    	if (!el.hasChildNodes()) return null;
    	return el.getFirstChild().getNodeValue();
    }
    
    private void insertDb() throws Exception {
    	String loginUser = "root";
        String loginPasswd = "lucifer";
        String loginUrl = "jdbc:mysql://localhost:3306/moviedb";

        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection connection = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);
        
        PreparedStatement psInsertRecord = null;
        String sqlInsertRecord = null;

        int[] iNoRows = null;
        
        sqlInsertRecord = "insert into stars (id, name, birthYear) values(?, ?, ?)";
        try {
			connection.setAutoCommit(false);

            psInsertRecord = connection.prepareStatement(sqlInsertRecord);
            
            int cnt = 0;
            
            for (Actor actor : actors) {
            	cnt++;
        		psInsertRecord.setString(1, "zz" + cnt);
        		if (actor.name == null) {
        			psInsertRecord.setNull(2, java.sql.Types.VARCHAR);
        		} else {
        			psInsertRecord.setString(2, actor.name);
        		}
        		if (actor.birthYear == 0) {
        			psInsertRecord.setNull(3, java.sql.Types.INTEGER);
        		} else {
        			psInsertRecord.setInt(3, actor.birthYear);
        		}
                psInsertRecord.addBatch();
            }
            
            iNoRows = psInsertRecord.executeBatch();

			connection.commit();

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if (psInsertRecord != null) psInsertRecord.close();
            if (connection != null) connection.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        //create an instance
        ActorParse test = new ActorParse();

        //call run example
        test.runExample();
    }

}
