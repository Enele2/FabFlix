function searchButton() {
	var query = document.getElementById("autocomplete").value;
	console.log("click search Button: " + query);
	handleNormalSearch(query);
}

/*
 * do normal full text search if no suggestion is selected
 */
function handleNormalSearch(query) {
	console.log("doing normal search with query: " + query);
	// set cookie here
	var movieName = query;
	window.location.href = "fullTextSearch.html?movieTitle=" + movieName;
//			+ "&year=" + "&director=" + "&star=" + "&page=20" + "&range=1"
//			+ "&sort=title";
}

// bind pressing enter key to a handler function
$('#autocomplete').keypress(function(event) {
	if (event.keyCode == 13) {
		handleNormalSearch($('#autocomplete').val())
	}
})

$('#autocomplete').autocomplete({
	lookup : function(query, doneCallback) {
		handleLookup(query, doneCallback)
	},
	onSelect : function(suggestion) {
		handleSelectSuggestion(suggestion)
	},
	minChars : 3,
	delimiter : /(,|;)\s*/,
	showNoSuggestionNotice : true,
	noSuggestionNotice : 'No results found',
	groupBy : "category",
	deferRequestBy : 300,
});

function handleLookup(query, doneCallback) {
	console.log("autocomplete initiated")
	console.log("handleLookup: You are searching for: " + query);
	var curr_data = getCookie(query);
	if (curr_data != "") {
		console.log("Get data from cache");
		handleLookupAjaxSuccess(curr_data, query, doneCallback);
	} else {
		console.log("Get data from servlet");
		jQuery.ajax({
			method : "GET",
			url : "api/SearchAutoComplete?query=" + escape(query),
			"success" : function(data) {
				 console.log(data);
				 setCookie(query, data);
				handleLookupAjaxSuccess(data, query, doneCallback);
			},
			"error" : function(errorData) {
				console.log("lookup ajax error");
				console.log(errorData);
			}
		})
	}
}

function handleLookupAjaxSuccess(data, query, doneCallback) {
	console.log("lookup ajax successful");
	console.log(data);
	var jsonData = JSON.parse(data);
	console.log(jsonData)
	doneCallback({
		suggestions : jsonData
	});
}

function handleSelectSuggestion(suggestion) {
	console.log("you select " + suggestion["value"])
	var method = suggestion["data"]["category"];
	console.log(method);
	if (method == "Movies") {
		var val = suggestion["data"]["heroID"];
		console.log("move to single movie" + val);
		window.location.href = "single-movie.html?movieId=" + val;
	} else if (method == "Stars") {
		var val = suggestion["value"];
		console.log("move to single star" + val);
		window.location.href = "single-star.html?starName=" + val;
	}
}

function checkCookie(query){
	if(getCookie(query) == null){
		setCookie("PassedSearchData");
	}
}

// Set key 
function setCookie(cname, cvalue)
{
  var d = new Date();
  d.setTime(d.getTime()+(1*60*60*1000));
  var expires = "expires="+d.toGMTString();
  document.cookie = cname + "=" + cvalue + "; " + expires;
}

function delCookie(name)  {  
        var exp = new Date();  
        exp.setTime(exp.getTime() - 1);  
        var cval=getCookie(name);  
        if(cval!=null)  
        document.cookie= name + "="+cval+";expires="+exp.toGMTString();  
} 

function getCookie(cname) {  
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i< ca.length; i++) 
	{
	    var c = ca[i].trim();
	    if (c.indexOf(name)==0) 
	    	return c.substring(name.length,c.length);
	}
	return "";
}  
