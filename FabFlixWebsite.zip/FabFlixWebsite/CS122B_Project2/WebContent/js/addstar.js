/**
 * Handle the data returned by LoginServlet
 * @param resultDataString jsonObject
 */
function handleSearchResult(resultDataString) {
    resultDataJson = JSON.parse(resultDataString);

    console.log("handle add result");
    console.log(resultDataJson);
    

    // If search succeeds, it will redirect the user to index.html
    if (resultDataJson["output"]) {
    	{
    		alert(resultDataJson["output"]);
    	}
        window.location.replace("addstar.html");
    } else {
        // If search fails, the web page will display 
        // error messages on <div> with id "login_error_message"
        console.log("show error message");
        console.log(resultDataJson["message"]);
        {
    		alert(resultDataJson["message"]);
    	}
        window.location.replace("addstar.html");
        //$("#addstar_error_message").text(resultDataJson["message"]);
    }
}

/**
 * Submit the form content with POST method
 * @param formSubmitEvent
 */
function submitSearchForm(formSubmitEvent) {
    console.log("submit addstar form");
    /**
     * When users click the submit button, the browser will not direct
     * users to the url defined in HTML form. Instead, it will call this
     * event handler when the event is triggered.
     */
    formSubmitEvent.preventDefault();

    $.post(
        "api/addstar",
        // Serialize the login form to the data sent by POST request
        $("#addstar_form").serialize(),
        (resultDataString) => handleSearchResult(resultDataString)
    );
}

// Bind the submit action of the form to a handler function
$("#addstar_form").submit((event) => submitSearchForm(event));
