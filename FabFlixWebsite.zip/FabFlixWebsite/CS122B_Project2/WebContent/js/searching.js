/**
 * Handle the data returned by LoginServlet
 * @param resultDataString jsonObject
 */
function handleSearchResult(resultDataString) {
    resultDataJson = JSON.parse(resultDataString);

    console.log("handle search result");
    console.log(resultDataJson);
    

    // If search succeeds, it will redirect the user to index.html
    if (resultDataJson) {
        window.location.replace("searchingresult.html");
    } else {
        // If search fails, the web page will display 
        // error messages on <div> with id "login_error_message"
        console.log("show error message");
        console.log(resultDataJson["message"]);
        $("#search_error_message").text(resultDataJson["message"]);
    }
}

/**
 * Submit the form content with POST method
 * @param formSubmitEvent
 */
function submitSearchForm(formSubmitEvent) {
    console.log("submit searching form");
    /**
     * When users click the submit button, the browser will not direct
     * users to the url defined in HTML form. Instead, it will call this
     * event handler when the event is triggered.
     */
    formSubmitEvent.preventDefault();

    $.post(
        "api/searching",
        // Serialize the login form to the data sent by POST request
        $("#searching_form").serialize(),
        (resultDataString) => handleSearchResult(resultDataString)
    );
}

// Bind the submit action of the form to a handler function
$("#searching_form").submit((event) => submitSearchForm(event));
