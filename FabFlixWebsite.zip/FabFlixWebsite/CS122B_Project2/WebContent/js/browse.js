let genre_hyperlinks = jQuery("#genre_input");

function handleResult(resultData) {
	let genre_hyperlinks_element = jQuery("#genre_input");

    for (let i = 0; i < Math.min(20, resultData.length); i++) {
    	let empty = "";
    	let hyperlink = "";
    	hyperlink += '<a href="browse-result.html?genre=' + resultData[i]['genre_name'] + '" style="color:darkcyan">'
    		+resultData[i]["genre_name"] + '</a>' + '<span class="navigationSpace"/>';
    	
        genre_hyperlinks_element.append(hyperlink);
    }
    
    let alphabet_hyperperlinks_element = jQuery("#title_input");
    for (let letter = 0; letter < 26; letter++) {
    	
    	let hyperlink = "";
    	hyperlink += '<a href="browse-result.html?title=' + (letter+10).toString(36) +'" style="color:darkcyan">' 
    		+ (letter+10).toString(36) + '</a>' + '<span class="navigationSpace"/>';
	
    	alphabet_hyperperlinks_element.append(hyperlink);
    }
    alphabet_hyperperlinks_element.append("<p></p>")
    
    for (let num = 0; num < 9; num++) {
    	let hyperlink = "";
    	hyperlink += '<a href="browse-result.html?title=' + num +'" style="color:darkcyan">' + num + '</a>' + '<span class="navigationSpace"/>';
	
    	alphabet_hyperperlinks_element.append(hyperlink);
    }
}

jQuery.ajax({
    dataType: "json", // Setting return data type
    method: "GET", // Setting request method
    url: "api/browse", // Setting request url, which is mapped by BrowseServlet in BrowseServlet.java
    success: (resultData) => handleResult(resultData) // Setting callback function to handle data returned successfully by the BrowseServlet
});