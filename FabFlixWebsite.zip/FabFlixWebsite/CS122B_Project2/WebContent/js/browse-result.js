function getParameterByName(target) {
    // Get request URL
    let url = window.location.href;
    // Encode target parameter name to url encoding
    target = target.replace(/[\[\]]/g, "\\$&");

    // Use regular expression to find matched parameter value
    let regex = new RegExp("[?&]" + target + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';

    // Return the decoded parameter value
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

let nPerPage = 0;
let res = null;
let pageIndex = 0;
let pageCount = 0;
var timeout	= 500;
var closetimer	= 0;
var ddmenuitem	= 0;

// open hidden layer
function mopen(id)
{	
	// cancel close timer
	mcancelclosetime();

	// close old layer
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';

	// get new layer and show it
	ddmenuitem = document.getElementById(id);
	ddmenuitem.style.visibility = 'visible';

}
// close showed layer
function mclose()
{
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';
}

// go close timer
function mclosetime()
{
	closetimer = window.setTimeout(mclose, timeout);
}

// cancel close timer
function mcancelclosetime()
{
	if(closetimer)
	{
		window.clearTimeout(closetimer);
		closetimer = null;
	}
}

// close layer when click-out
document.onclick = mclose; 

function prev() {
	if(pageIndex == 0) {
		alert("This is the first page!");
		return;
	}
	pageIndex--;
	showCurrentPage();
}

function next() {
	if(pageIndex == pageCount - 1) {
		alert("This is the last page!");
		return;
	}
	pageIndex++;
	showCurrentPage();
}

function sortingByTitle() {
	jQuery.ajax({
	    dataType: "json", // Setting return data type
	    method: "GET", // Setting request method
	    url: "api/sortbytitle", // Setting request url, which is mapped by MovieServlet in MovieServlet.java
	    success: (resultData) => handleMovieResult(resultData) // Setting callback function to handle data returned successfully by the StarsServlet
	});
}

function sortingByRating() {
	window.location.href = "index.php?order="+order;
}

function doPagination(n) {
	nPerPage = n;
	pageCount = Math.ceil(res.length / nPerPage);
    pageIndex = 0;
    
    console.log("pageIndex " + pageIndex);
    console.log("pageCount " + pageCount);
    
    showCurrentPage();
}

function showCurrentPage() {
	let movieTableBodyElement = jQuery("#movie_table_body");
	
	movieTableBodyElement.html(""); // clear all rows in table
    
	for (let i = pageIndex * nPerPage; i < Math.min((pageIndex + 1) * nPerPage, res.length); i++) {
    	console.log("current: " + i);
    	
        // Concatenate the html tags with resultData jsonObject
        let rowHTML = "";
        rowHTML += "<tr>";
        rowHTML +=
            "<td>" +
            // Add a link to single-movie.html with id passed with GET url
			// parameter
            '<a href="single-movie.html?id=' + res[i]['movie_id'] + '">'
            + res[i]["movie_title"] +     // display star_name for the link
											// text
            '</a>' +
            "</td>";
      
        rowHTML += "<td>" + res[i]["movie_year"] + "</td>";
        rowHTML += "<td>" + res[i]["movie_director"] + "</td>";
        rowHTML += "<td>" + res[i]["movie_genres"] + "</td>";
        
        // rowHTML += "<th>" + resultData[i]["movie_stars"] + "</th>";
        let listOfStars = res[i]["movie_stars"];
        
        console.log(listOfStars);
        let tokens = listOfStars.split(",");
        rowHTML += "<td>";
        for(let j = 0; j < tokens.length; j++)
        {
        	if(j === 0){
        		rowHTML += '<a href="single-star.html?name=' + tokens[j] + '">' + tokens[j] + '</a>';
        	} else {
        		rowHTML += '<a href="single-star.html?name=' + tokens[j] + '">,' + tokens[j] + '</a>';
        	}
        } 
        rowHTML += "</td>";
        
        rowHTML += "<td>" + res[i]["movie_rating"] + "</td>";
        rowHTML += "</tr>";

        // Append the row created to the table body, which will refresh the page
        movieTableBodyElement.append(rowHTML);
    }
}

function doPagination(n) {
	nPerPage = n;
	pageCount = Math.ceil(res.length / nPerPage);
    pageIndex = 0;
    
    console.log("pageIndex " + pageIndex);
    console.log("pageCount " + pageCount);
    
    showCurrentPage();
}

function handleResult(resultData) {
    //console.log("handleMovieResult: populating star table from resultData");
    res = JSON.parse(resultData["data"]);
}


//Get parameters from URL
let genre = getParameterByName('genre');
let title = getParameterByName('title');

//Makes the HTTP GET request and registers on success callback function handleResult
if(genre != null && title == null) {
jQuery.ajax({
    dataType: "json",  // Setting return data type
    method: "GET",// Setting request method
    url: "api/browse-results?genre=" + genre, // Setting request url, which is mapped by StarsServlet in Stars.java
    success: (resultData) => handleResult(resultData) // Setting callback function to handle data returned successfully by the SingleStarServlet
}); }else if(genre == null && title != null) {
		jQuery.ajax({
		    dataType: "json",  // Setting return data type
		    method: "GET",// Setting request method
		    url: "api/browse-results?title=" + title, // Setting request url, which is mapped by StarsServlet in Stars.java
		    success: (resultData) => handleResult(resultData) // Setting callback function to handle data returned successfully by the SingleStarServlet
}); } else {
		jQuery.ajax({
		    dataType: "json",  // Setting return data type
		    method: "GET",// Setting request method
		    url: "api/browse-results", // Setting request url, which is mapped by StarsServlet in Stars.java
		    success: (resultData) => handleResult(resultData) // Setting callback function to handle data returned successfully by the SingleStarServlet
}); }