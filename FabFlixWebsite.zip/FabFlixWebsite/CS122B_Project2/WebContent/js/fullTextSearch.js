/*
 * initize the webpage
 */
$().ready(function(){
    var URL = document.location.toString(); // 获取带参URL
    var para = URL.split("?");
    console.log("000");
    $.ajax({
    	dataType: "json",
  	  	method: "GET",
  	  	url: "api/SearchFullText?" + para[1],
  	  	success: (resultData) => handleStarResult(resultData),
  	  	error : function(xhr, status, errMsg)
        {
             alert("fail!");
        }
	});
});

function handleStarResult(resultData) {
	console.log("handleStarResult: populating search result from resultData");
	// populate the search result
	var starTableBodyElement = jQuery("#search_movie_result");
	for (var i = 0; i < resultData.length; i++) {
		var rowHTML = "";
		rowHTML += "<tr class = row >";
		rowHTML += "<th class = cell id = "+ resultData[i]["id"] +" onClick = singleMovie(this.id)>" +resultData[i]["title"] + "</th>";
		rowHTML += "<th class = cell>" +resultData[i]["year"] + "</th>";
		rowHTML += "<th class = cell>" +resultData[i]["director"] + "</th>";
		rowHTML += "<th class = cell>" +resultData[i]["genre"] + "</th>";
		rowHTML += "<th class = cell>" +resultData[i]["star"] + "</th>";
		rowHTML += "<th class = cell id = "+ resultData[i]["id"] +" onClick = addChart(this.id)>" +"add to chart" + "</th>";
		rowHTML += "</tr>"
		starTableBodyElement.append(rowHTML);
	}
}

function singleMovie(val){
	console.log("move to single movie");
    //window.location.href = "singlemovie.html?movieId=" + val;
}